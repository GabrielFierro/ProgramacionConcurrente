/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trenTuristico;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabriel.fierro
 */
public class Vendedor extends Thread {
    // Clase correspondiente al vendedor que es quien vende tickets en la Cabina

    private String nombre;
    private Cabina cab;
    private int cant;
    private boolean exito;

    public Vendedor(String nombre, Cabina cab, int cant) {
        this.nombre = nombre;
        this.cab = cab;
        this.cant = cant;
    }

    @Override
    public void run() {
        for (int i = 0; i < this.cant; i++) {
            try {
                exito = cab.puedeEmitirPasaje();
                if (exito) {
                    System.out.println("El vendedor " + this.nombre + " esta vendiendo un ticket");
                    Thread.sleep(1000);
                    cab.venderPasaje();
                } else {
                    System.out.println("El vendedor " + this.nombre + " no pudo vender un ticket");
                }

            } catch (InterruptedException ex) {
                Logger.getLogger(Vendedor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
